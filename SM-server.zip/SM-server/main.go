package main
import (
    "github.com/gin-gonic/gin"
    "github.com/6tail/lunar-go/calendar"
    "net/http"
)
type BaziResponse struct {
    YearGanZhi    int `json:"yearGanZhi"`
    MonthGanZhi   int `json:"monthGanZhi"`
    DayGanZhi     int `json:"dayGanZhi"`
    HourGanZhi    int `json:"hourGanZhi"`
    NaYin         string `json:"naYin"`
    Week          string `json:"week"`
    Star          string `json:"star"`
    Xingxiu       string `json:"xingxiu"`
    Pengzu        string `json:"pengzu"`
    Xishen        string `json:"xishen"`
    Yangguishen   string `json:"yangguishen"`
    Yinguishen    string `json:"yinguishen"`
    Fushen        string `json:"fushen"`
    Caishen       string `json:"caishen"`
    Chong         string `json:"chong"`
    Sha           string `json:"sha"`
    Solar         string `json:"solar"`
}

type BaziRequest struct {
    Name   string `json:"name"`
    Gender string `json:"gender"`
    Year   int    `json:"year"`
    Month  int    `json:"month"`
    Day    int    `json:"day"`
    Hour   int    `json:"hour"`
}

func main() {
    r := gin.Default()
    r.POST("/api/bazi", handleBazi)
    r.Run(":8080")
}

func handleBazi(c *gin.Context) {
    var req BaziRequest
    if err := c.ShouldBindJSON(&req); err != nil {
        c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
        return
    }
    lunar := calendar.NewLunarFromYmd(req.Year, req.Month, req.Day)
    solar := lunar.GetSolar()
    resp := BaziResponse{
        YearGanZhi:  solar.GetYear(),
        MonthGanZhi: solar.GetMonth(),
        DayGanZhi:   solar.GetDay(),
        HourGanZhi:  solar.GetHour(),
        NaYin:       lunar.GetDayNaYin(),
        Week:        solar.GetWeekInChinese(),
        Star:        lunar.GetPositionXi(),
        Xingxiu:     lunar.GetXiu() + lunar.GetXiuLuck(),
        Pengzu:      lunar.GetPengZuGan() + " " + lunar.GetPengZuZhi(),
        Xishen:      lunar.GetDayPositionXiDesc(),
        Yangguishen: lunar.GetDayPositionYangGuiDesc(),
        Yinguishen:  lunar.GetDayPositionYinGuiDesc(),
        Fushen:      lunar.GetDayPositionFuDesc(),
        Caishen:     lunar.GetDayPositionCaiDesc(),
        Chong:       lunar.GetChongDesc(),
        Sha:         lunar.GetSha(),
        Solar:       solar.ToFullString(),
    }

    c.JSON(http.StatusOK, resp)
}