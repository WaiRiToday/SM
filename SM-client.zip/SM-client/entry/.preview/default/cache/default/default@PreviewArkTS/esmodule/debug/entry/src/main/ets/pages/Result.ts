if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Result_Params {
    paramsWrap?: ParamsWrap;
    result?: BaziResult;
}
import router from "@ohos:router";
interface ParamsWrap {
    result: string;
}
interface BaziResult {
    yearGanZhi: string;
    monthGanZhi: string;
    dayGanZhi: string;
    hourGanZhi: string;
    naYin: string;
    week: string;
    star: string;
    xingxiu: string;
    pengzu: string;
    xishen: string;
    yangguishen: string;
    yinguishen: string;
    fushen: string;
    caishen: string;
    chong: string;
    sha: string;
    solar: string;
}
class Result extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.paramsWrap = router.getParams() as ParamsWrap;
        this.result = JSON.parse(this.paramsWrap.result);
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Result_Params) {
        if (params.paramsWrap !== undefined) {
            this.paramsWrap = params.paramsWrap;
        }
        if (params.result !== undefined) {
            this.result = params.result;
        }
    }
    updateStateVars(params: Result_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private paramsWrap: ParamsWrap;
    private result: BaziResult;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 10 });
            Column.debugLine("entry/src/main/ets/pages/Result.ets(34:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.padding(20);
            Column.backgroundColor('#F5F5F5');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('年柱：' + (this.result.yearGanZhi ?? ''));
            Text.debugLine("entry/src/main/ets/pages/Result.ets(35:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('月柱：' + (this.result.monthGanZhi ?? ''));
            Text.debugLine("entry/src/main/ets/pages/Result.ets(36:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('日柱：' + (this.result.dayGanZhi ?? ''));
            Text.debugLine("entry/src/main/ets/pages/Result.ets(37:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('时柱：' + (this.result.hourGanZhi ?? ''));
            Text.debugLine("entry/src/main/ets/pages/Result.ets(38:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.result.naYin ?? '');
            Text.debugLine("entry/src/main/ets/pages/Result.ets(39:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.result.week ?? '');
            Text.debugLine("entry/src/main/ets/pages/Result.ets(40:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.result.star ?? '');
            Text.debugLine("entry/src/main/ets/pages/Result.ets(41:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.result.xingxiu ?? '');
            Text.debugLine("entry/src/main/ets/pages/Result.ets(42:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.result.pengzu ?? '');
            Text.debugLine("entry/src/main/ets/pages/Result.ets(43:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.result.xishen ?? '');
            Text.debugLine("entry/src/main/ets/pages/Result.ets(44:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.result.yangguishen ?? '');
            Text.debugLine("entry/src/main/ets/pages/Result.ets(45:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.result.yinguishen ?? '');
            Text.debugLine("entry/src/main/ets/pages/Result.ets(46:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.result.fushen ?? '');
            Text.debugLine("entry/src/main/ets/pages/Result.ets(47:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.result.caishen ?? '');
            Text.debugLine("entry/src/main/ets/pages/Result.ets(48:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.result.chong ?? '');
            Text.debugLine("entry/src/main/ets/pages/Result.ets(49:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.result.sha ?? '');
            Text.debugLine("entry/src/main/ets/pages/Result.ets(50:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.result.solar ?? '');
            Text.debugLine("entry/src/main/ets/pages/Result.ets(51:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('返回');
            Button.debugLine("entry/src/main/ets/pages/Result.ets(52:7)", "entry");
            Button.width('80%');
            Button.margin({ top: 20, bottom: 20 });
            Button.onClick(() => {
                router.back();
            });
        }, Button);
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Result";
    }
}
registerNamedRoute(() => new Result(undefined, {}), "", { bundleName: "com.example.sm", moduleName: "entry", pagePath: "pages/Result", pageFullPath: "entry/src/main/ets/pages/Result", integratedHsp: "false", moduleType: "followWithHap" });
