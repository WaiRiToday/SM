if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Home_Params {
    name?: string;
    gender?: string;
    year?: string;
    month?: string;
    day?: string;
    hour?: string;
}
import router from "@ohos:router";
import http from "@ohos:net.http";
import promptAction from "@ohos:promptAction";
interface BaziRequest {
    name: string;
    gender: string;
    year: number;
    month: number;
    day: number;
    hour: number;
}
interface BaziResult {
    yearGanZhi: number;
    monthGanZhi: number;
    dayGanZhi: number;
    hourGanZhi: number;
    naYin: string;
    week: string;
    star: string;
    xingxiu: string;
    pengzu: string;
    xishen: string;
    yangguishen: string;
    yinguishen: string;
    fushen: string;
    caishen: string;
    chong: string;
    sha: string;
    solar: string;
}
class Home extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.name = '';
        this.gender = '男';
        this.year = '';
        this.month = '';
        this.day = '';
        this.hour = '';
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Home_Params) {
        if (params.name !== undefined) {
            this.name = params.name;
        }
        if (params.gender !== undefined) {
            this.gender = params.gender;
        }
        if (params.year !== undefined) {
            this.year = params.year;
        }
        if (params.month !== undefined) {
            this.month = params.month;
        }
        if (params.day !== undefined) {
            this.day = params.day;
        }
        if (params.hour !== undefined) {
            this.hour = params.hour;
        }
    }
    updateStateVars(params: Home_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private name: string;
    private gender: string;
    private year: string;
    private month: string;
    private day: string;
    private hour: string;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 16 });
            Column.debugLine("entry/src/main/ets/pages/Home.ets(44:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.padding(20);
            Column.backgroundColor('#F5F5F5');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('☯');
            Text.debugLine("entry/src/main/ets/pages/Home.ets(45:7)", "entry");
            Text.fontSize(30);
            Text.fontWeight(FontWeight.Bold);
            Text.margin({ top: 40, bottom: 10 });
            Text.alignSelf(ItemAlign.Center);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入姓名（可选）', text: this.name });
            TextInput.debugLine("entry/src/main/ets/pages/Home.ets(51:7)", "entry");
            TextInput.onChange((value: string) => { this.name = value; });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Home.ets(54:7)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('性别：');
            Text.debugLine("entry/src/main/ets/pages/Home.ets(55:9)", "entry");
            Text.fontSize(18);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Radio.create({ value: '男', group: 'gender' });
            Radio.debugLine("entry/src/main/ets/pages/Home.ets(56:9)", "entry");
            Radio.checked(this.gender === '男');
            Radio.onChange(() => { this.gender = '男'; });
        }, Radio);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('男');
            Text.debugLine("entry/src/main/ets/pages/Home.ets(59:9)", "entry");
            Text.fontSize(16);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Radio.create({ value: '女', group: 'gender' });
            Radio.debugLine("entry/src/main/ets/pages/Home.ets(60:9)", "entry");
            Radio.checked(this.gender === '女');
            Radio.onChange(() => { this.gender = '女'; });
        }, Radio);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('女');
            Text.debugLine("entry/src/main/ets/pages/Home.ets(63:9)", "entry");
            Text.fontSize(16);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '出生年份（如1990）', text: this.year });
            TextInput.debugLine("entry/src/main/ets/pages/Home.ets(66:7)", "entry");
            TextInput.onChange((value: string) => { this.year = value; });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '出生月份（1-12）', text: this.month });
            TextInput.debugLine("entry/src/main/ets/pages/Home.ets(69:7)", "entry");
            TextInput.onChange((value: string) => { this.month = value; });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '出生日（1-31）', text: this.day });
            TextInput.debugLine("entry/src/main/ets/pages/Home.ets(72:7)", "entry");
            TextInput.onChange((value: string) => { this.day = value; });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '出生时辰（0-23）', text: this.hour });
            TextInput.debugLine("entry/src/main/ets/pages/Home.ets(75:7)", "entry");
            TextInput.onChange((value: string) => { this.hour = value; });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('开始八字分析');
            Button.debugLine("entry/src/main/ets/pages/Home.ets(78:7)", "entry");
            Button.fontSize(20);
            Button.width('80%');
            Button.height(50);
            Button.backgroundColor('#007DFF');
            Button.fontColor(Color.White);
            Button.borderRadius(8);
            Button.alignSelf(ItemAlign.Center);
            Button.margin({ top: 20 });
            Button.onClick(() => {
                // 参数校验可选
                let requestData: BaziRequest = {
                    name: this.name,
                    gender: this.gender,
                    year: Number(this.year),
                    month: Number(this.month),
                    day: Number(this.day),
                    hour: Number(this.hour)
                };
                let httpRequest = http.createHttp();
                httpRequest.request('http://192.168.8.253:8080/api/bazi', // 替换为你的后端地址
                {
                    method: http.RequestMethod.POST,
                    header: { 'Content-Type': 'application/json' },
                    extraData: JSON.stringify(requestData),
                    connectTimeout: 6000,
                    readTimeout: 6000
                }, (err, data) => {
                    if (!err && data.responseCode === 200) {
                        // 处理返回数据
                        // 例如跳转到结果页
                        router.pushUrl({
                            url: 'pages/Result',
                            params: { data: data.result }
                        });
                    }
                    else {
                        promptAction.showToast({ message: '请求失败，请检查网络或输入' });
                    }
                    httpRequest.destroy();
                });
            });
        }, Button);
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Home";
    }
}
registerNamedRoute(() => new Home(undefined, {}), "", { bundleName: "com.example.sm", moduleName: "entry", pagePath: "pages/Home", pageFullPath: "entry/src/main/ets/pages/Home", integratedHsp: "false", moduleType: "followWithHap" });
